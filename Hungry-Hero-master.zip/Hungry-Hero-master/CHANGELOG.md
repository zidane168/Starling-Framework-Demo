Hungry Hero Game: Changelog
===========================

Version 1.0
-----------

* First version of the source.